from typing import ValuesView
from django.shortcuts import render

from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from . models import patient
from . serializers import patientSerializer




def homepage(request):
    return render(request, 'testApp/homepage.html')


class patientObjects(APIView):
    def get(self,request):
        patients = patient.objects.all()
        serialize=patientSerializer(patients, many =True)
        return Response(serialize.data)

    def post(self):
        pass