from django.contrib import admin
from . models import patient

admin.site.register(patient)